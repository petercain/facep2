import sqlite3
import random

AM = "아메리카노"
AMP = 2000

KL = "까페라떼"
KLP = 2500

KM = "카라멜 마끼아또"
KMP = 2700

CM = "까페모카"
CMP = 2700

HEY = "헤이즐넛"
HEYP = 2600

KP = "까푸치노"
KPP = 2900


#si는 '시' 입니다.
#bun은 '분'입니다
si = ["09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22"]
bun = ["01", "02", "03", "04", "05", "06", "07", "08", "09","10"]
for i in range(50):
    i += 11
    i = str(i)
    bun.append(i)

#일만 있는 리스트인데 다른 일도 넣고 싶으면 다른 일 추가하시면 됩니다.
nal = ["01", "02", "03", "04", "05", "06", "07", "08", "09"]

#날짜를 랜덤으로 뽑는다는 뜻
Y = random.choice(nal)
#X에서 연독와 월은 고정인데 이것도 리스트 만들고 랜덤으로 돌리면 다른 연도와 월도 넣을 수 있읍니다.
X = "2021-09-{}".format(Y)

#시간과 분
S = random.choice(si)
Z = random.choice(bun)
TI = "{}:{}".format(S,Z)

conn = sqlite3.connect("Star_Bucks.db", isolation_level=None)
cur = conn.cursor()

#반복횟수는 랜덤로직짜서 해도되고 수동으로 돌리셔도 됩니다.
for kk in range(21):
    Y = random.choice(nal)
    X = "2021-09-{}".format(Y)
    S = random.choice(si)
    Z = random.choice(bun)
    TI = "{}:{}".format(S, Z)

    cur.execute("INSERT INTO order_data(ID, Menu, Price, Day, Time, Branch_name)VALUES(?,?,?,?,?,?)",
                        ("김더미", KP, KPP, X, TI, "시애틀본점"))

    #음료수도 랜덤으로 돌리고 싶으면 리스트 만들어서 돌리시면 됩니다. 지점 이름은 두개밖에 없어서 수동으로 입력하시면 됩니다.


