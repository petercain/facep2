# import sys
# from PyQt5.QtWidgets import *
# from PyQt5 import uic
# from PyQt5 import QtGui
# import sqlite3
#
# pageOneUi = 'combobox.ui'
#
# class pageOne(QMainWindow):
#
#     def __init__(self):
#         super().__init__()
#         uic.loadUi(pageOneUi, self)
#
#         self.search = "{}-{}-{}".format(self.comboBox.currentText(), self.comboBox_2.currentText(), self.comboBox_3.currentText())
#
#         self.pushButton.clicked.connect(self.bt)
#
#     def bt(self):
#         print(self.search)
#         conn = sqlite3.connect("Star_Bucks.db", isolation_level=None)
#         cur = conn.cursor()
#         cur.execute("select * from order_data where Day = '{}'".format(self.search))
#         result = cur.fetchall()
#         print(result)
#         print(type(result))
#
#         for i in range(len(result)):
#             self.textBrowser.append("{}".format(result[i]))
#
#
# app = QApplication(sys.argv)
# ch = pageOne()
# ch.show()
# app.exec_()

dayday = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10"]
for i in range(20):
    i += 11
    i = str(i)
    dayday.append(i)

print(dayday)
